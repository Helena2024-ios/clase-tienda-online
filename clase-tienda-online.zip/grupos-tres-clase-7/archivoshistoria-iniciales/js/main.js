// PRODUCTOS
const productos = [
    // Hombre
    {
        "id": "hombre-01",
        "titulo": "Hombre 01",
        "imagen": "./img/hombre/01.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 85200
    },
    {
        "id": "hombre-02",
        "titulo": "Hombre 02",
        "imagen": "./img/hombre/02.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 123000
    },
    {
        "id": "hombre-03",
        "titulo": "Hombre 03",
        "imagen": "./img/hombre/03.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 108000
    },
    {
        "id": "hombre-04",
        "titulo": "Hombre 04",
        "imagen": "./img/hombre/04.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 105000
    },
    {
        "id": "hombre-05",
        "titulo": "Hombre 05",
        "imagen": "./img/hombre/05.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 98000
    },
    {
        "id": "hombre-06",
        "titulo": "Hombre 06",
        "imagen": "./img/hombre/06.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 102000
    },
    {
        "id": "hombre-07",
        "titulo": "Hombre 07",
        "imagen": "./img/hombre/07.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 123000
    },
    {
        "id": "hombre-08",
        "titulo": "Hombre 08",
        "imagen": "./img/hombre/08.jpg",
        "categoria": {
            "nombre": "Hombre",
            "id": "hombre"
        },
        "precio": 120000
    },

    // Mujer
    {
        "id": "mujer-01",
        "titulo": "Mujer 01",
        "imagen": "./img/mujer/01.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 85000
    },
    {
        "id": "mujer-02",
        "titulo": "Mujer 02",
        "imagen": "./img/mujer/02.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 112000
    },
    {
        "id": "mujer-03",
        "titulo": "Mujer 03",
        "imagen": "./img/mujer/03.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 96000
    },
    {
        "id": "mujer-04",
        "titulo": "Mujer 04",
        "imagen": "./img/mujer/04.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 95000
    },
    {
        "id": "mujer-05",
        "titulo": "Mujer 05",
        "imagen": "./img/mujer/05.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 115000
    },
    {
        "id": "mujer-06",
        "titulo": "Mujer 06",
        "imagen": "./img/mujer/06.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 114000
    },
    {
        "id": "mujer-07",
        "titulo": "Mujer 07",
        "imagen": "./img/mujer/07.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 112000
    },
    {
        "id": "mujer-08",
        "titulo": "Mujer 08",
        "imagen": "./img/mujer/08.jpg",
        "categoria": {
            "nombre": "Mujer",
            "id": "mujer"
        },
        "precio": 56000
    },
    // Niños
    {
        "id": "niños-01",
        "titulo": "Niños 01",
        "imagen": "./img/niños/01.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 35000
    },
    {
        "id": "niños-02",
        "titulo": "Niños 02",
        "imagen": "./img/niños/02.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 45000
    },
    {
        "id": "niños-03",
        "titulo": "Niños 03",
        "imagen": "./img/niños/03.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 50500
    },
    {
        "id": "niños-04",
        "titulo": "Niños 04",
        "imagen": "./img/niños/04.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 35000
    },
    {
        "id": "niños-05",
        "titulo": "Niños 05",
        "imagen": "./img/niños/05.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 25000
    },
    {
        "id": "niños-06",
        "titulo": "Niños 06",
        "imagen": "./img/niños/06.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 45000
    },
    {
        "id": "niños-07",
        "titulo": "Niños 07",
        "imagen": "./img/niños/07.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 25000
    },
    {
        "id": "niños-08",
        "titulo": "Niños 08",
        "imagen": "./img/niños/08.jpg",
        "categoria": {
            "nombre": "Niños",
            "id": "niños"
        },
        "precio": 36000
    }
];